Nome: Jefferson Michael de Azevedo Junior ra:2058979
Nome: Vagner de Oliveira Conhariki        ra:2057530

AedesFinal.c -> Arquivo final do projeto que deve ser avaliado.

AedesParaTESTES -> Arquivo EXTRA para testes mais claros das açoes dos mosquitos e agentes.

entradax.txt -> alguns exemplos de entradas.
